# J.T.M Graphics Landing Page - Design Brainstorm

## Extracted Brand Elements
- **Logo**: Modern "JTM" wordmark in navy blue and white
- **Color Palette**: Navy blue (#1e3a5f), white, clean professional tones
- **Aesthetic**: Modern, professional, creative
- **Services**: Logo design, flyers, posters, brochures, song artwork
- **Location**: Lusaka, Zambia
- **Tagline**: Fast • Affordable • High Quality

---

## Design Approach 1: Modern Minimalist with Geometric Accents
**Probability**: 0.08

**Design Movement**: Contemporary Minimalism with Swiss Grid Influence

**Core Principles**:
- Extreme whitespace and breathing room between elements
- Geometric shapes (circles, diagonal cuts) as visual punctuation
- Monochromatic navy base with single accent color (vibrant teal)
- Typography as primary visual hierarchy tool

**Color Philosophy**:
- Primary: Navy (#1e3a5f) for authority and professionalism
- Accent: Vibrant Teal (#00d4ff) for creative energy and call-to-action
- Background: Off-white (#fafbfc) for subtle texture
- Reasoning: Navy conveys trust and expertise; teal signals innovation and creativity

**Layout Paradigm**:
- Asymmetric grid with generous left margin (40% white space on desktop)
- Staggered card layouts that break the grid intentionally
- Diagonal section dividers with negative space compensation
- Right-aligned content blocks with left-side visual anchors

**Signature Elements**:
- Geometric circle badges for service categories
- Thin navy lines connecting related content
- Diagonal clip-path transitions between sections
- Floating geometric shapes in background (subtle, low opacity)

**Interaction Philosophy**:
- Minimal hover effects: subtle color shift and scale (1.02x)
- Smooth scroll-triggered reveals with fade-in animations
- Floating elements that respond to mouse movement
- Micro-interactions on form inputs (underline animations)

**Animation**:
- Entrance: Fade-in with 0.3s ease-out on scroll
- Hover: 0.2s cubic-bezier(0.34, 1.56, 0.64, 1) for spring effect
- Scroll parallax on hero background (20% offset)
- Form inputs: Underline grows from left on focus

**Typography System**:
- Display: "Poppins" Bold (700) for headlines (48px-72px)
- Subheading: "Poppins" SemiBold (600) for section titles (24px-32px)
- Body: "Inter" Regular (400) for content (16px-18px)
- Accent: "Poppins" Medium (500) for CTAs and labels

---

## Design Approach 2: Bold Creative Studio Aesthetic
**Probability**: 0.07

**Design Movement**: Contemporary Creative Studio Design

**Core Principles**:
- High contrast and bold typography dominates
- Vibrant color blocking with intentional color clashes
- Large, immersive hero imagery with text overlay
- Experimental layout that breaks traditional grids

**Color Philosophy**:
- Primary: Deep Navy (#1a2a4a) for grounding
- Secondary: Burnt Orange (#d97706) for creative warmth
- Accent: Lime Green (#84cc16) for energy and playfulness
- Background: Dark charcoal (#1f2937) for sophistication
- Reasoning: Bold color combinations signal creative confidence and artistic vision

**Layout Paradigm**:
- Full-width hero with overlapping text and imagery
- Masonry-style portfolio grid with varied card sizes
- Diagonal text placements and rotated elements
- Overlapping sections with color blocks as backgrounds

**Signature Elements**:
- Large, bold typography with letter-spacing variations
- Colored geometric overlays on portfolio images
- Hand-drawn style dividers and accent lines
- Animated gradient backgrounds on service cards

**Interaction Philosophy**:
- Aggressive hover animations: scale (1.08x), color shift, shadow expansion
- Parallax scrolling on hero and portfolio sections
- Animated counters for statistics
- Interactive portfolio filters with smooth transitions

**Animation**:
- Entrance: Slide-in from sides with 0.5s ease-out
- Hover: 0.3s cubic-bezier(0.34, 1.56, 0.64, 1) with scale and color
- Scroll: Staggered reveals with 0.1s delay between items
- Portfolio: Image zoom and overlay fade on hover

**Typography System**:
- Display: "Space Grotesk" Bold (700) for headlines (56px-80px)
- Subheading: "Space Grotesk" SemiBold (600) for titles (28px-36px)
- Body: "Outfit" Regular (400) for content (16px-18px)
- Accent: "Space Grotesk" Bold (700) for CTAs (14px-16px)

---

## Design Approach 3: Elegant Professional with Subtle Sophistication
**Probability**: 0.09

**Design Movement**: Contemporary Professional Design with Luxury Minimalism

**Core Principles**:
- Refined elegance through careful typography and spacing
- Soft gradients and subtle textures for depth
- Muted color palette with strategic accent highlights
- Emphasis on readability and user comfort

**Color Philosophy**:
- Primary: Navy (#2c3e50) for authority
- Secondary: Slate Gray (#64748b) for supporting content
- Accent: Soft Gold (#d4af37) for premium feel
- Background: Cream (#fef9f3) for warmth and approachability
- Reasoning: Sophisticated palette conveys premium quality and trustworthiness

**Layout Paradigm**:
- Centered, symmetrical layout with generous padding
- Vertical rhythm maintained throughout (8px baseline grid)
- Subtle left-side accent bars for section emphasis
- Card-based design with soft shadows and rounded corners

**Signature Elements**:
- Vertical accent lines in gold on the left of key sections
- Subtle gradient backgrounds (navy to transparent)
- Elegant serif accents on headings
- Soft drop shadows and blur effects for depth

**Interaction Philosophy**:
- Subtle, refined hover effects: gentle color shift and shadow enhancement
- Smooth scroll animations with fade and slide combinations
- Elegant form interactions with label animations
- Refined transitions on all interactive elements

**Animation**:
- Entrance: Fade-in with slight upward movement (20px) over 0.4s
- Hover: 0.25s ease-in-out with subtle shadow and color shift
- Scroll: Staggered fade-in with 0.15s delay between items
- Form: Smooth label float and underline animations

**Typography System**:
- Display: "Merriweather" Bold (700) for headlines (48px-64px)
- Subheading: "Merriweather" SemiBold (600) for titles (24px-32px)
- Body: "Lato" Regular (400) for content (16px-18px)
- Accent: "Lato" Medium (500) for labels and CTAs

---

## Selected Approach: **Elegant Professional with Subtle Sophistication**

This approach best matches J.T.M Graphics' professional identity while maintaining creative credibility. The refined color palette (navy, slate, gold, cream) reflects the brand's established aesthetic, while the sophisticated layout and typography convey premium quality and trustworthiness—key factors for a design service business.

**Key Design Decisions**:
- Navy and gold color scheme aligns with the existing JTM logo
- Cream background provides warmth and approachability for potential clients
- Serif accents on headings add creative flair while maintaining professionalism
- Generous spacing and careful typography hierarchy ensure readability and elegance
- Subtle animations enhance user experience without distraction
- Card-based layout showcases portfolio work effectively
