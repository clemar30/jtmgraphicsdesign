import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Palette, PenTool, BookOpen, Music } from "lucide-react";
import ContactForm from "@/components/ContactForm";

/**
 * Design Philosophy: Elegant Professional with Subtle Sophistication
 * Color Palette: Navy (#2c3e50), Slate Gray (#64748b), Soft Gold (#d4af37), Cream (#fef9f3)
 * Typography: Merriweather (serif) for headlines, Lato (sans-serif) for body
 * Layout: Centered, symmetrical with generous padding and vertical rhythm
 */

export default function Home() {
  const services = [
    {
      icon: Palette,
      title: "Logo Design",
      description:
        "Custom, memorable logos that represent your brand identity and values.",
    },
    {
      icon: PenTool,
      title: "Flyers & Posters",
      description:
        "Eye-catching promotional materials designed to capture attention and drive engagement.",
    },
    {
      icon: BookOpen,
      title: "Brochures & Prints",
      description:
        "Professional printed materials that communicate your message effectively.",
    },
    {
      icon: Music,
      title: "Song Artwork",
      description:
        "Stunning album covers and artwork for musicians and artists.",
    },
  ];

  const portfolio = [
    {
      title: "Brand Identity Package",
      category: "Branding",
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663642279787/BCDhxD4AafGniUf7vHA5ze/jtm-service-design-ZbrzxtZMzsftjGy35uNcka.webp",
    },
    {
      title: "Beauty Salon Campaign",
      category: "Marketing",
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663642279787/BCDhxD4AafGniUf7vHA5ze/jtm-portfolio-accent-CpuA8n24jM7ggmTf2b5Cet.webp",
    },
    {
      title: "Product Launch Design",
      category: "Advertising",
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663642279787/BCDhxD4AafGniUf7vHA5ze/jtm-service-design-ZbrzxtZMzsftjGy35uNcka.webp",
    },
  ];

  const testimonials = [
    {
      name: "Sarah M.",
      role: "Beauty Salon Owner",
      text: "JTM Graphics delivered exceptional designs that perfectly captured our brand. Fast, affordable, and high quality!",
    },
    {
      name: "James K.",
      role: "Music Producer",
      text: "The album artwork was stunning. Professional and creative. Highly recommend!",
    },
    {
      name: "Amara L.",
      role: "Business Owner",
      text: "Outstanding service. The team understood our vision and delivered beyond expectations.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">JTM</span>
            </div>
            <span className="font-bold text-primary hidden sm:inline">
              J.T.M Graphics
            </span>
          </div>
          <nav className="hidden md:flex gap-8">
            <a href="#services" className="text-foreground hover:text-accent transition-colors">
              Services
            </a>
            <a href="#portfolio" className="text-foreground hover:text-accent transition-colors">
              Portfolio
            </a>
            <a href="#contact" className="text-foreground hover:text-accent transition-colors">
              Contact
            </a>
          </nav>
          <Button
            onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            Get Started
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage:
              "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663642279787/BCDhxD4AafGniUf7vHA5ze/jtm-hero-background-mX9wBWjRESBrsaLWKJCJUm.webp')",
          }}
        />
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-block mb-6 px-4 py-2 bg-accent/10 rounded-full border border-accent/30">
              <span className="text-accent font-medium text-sm">
                Professional Graphic Design Services
              </span>
            </div>
            <h1 className="text-primary mb-6 leading-tight">
              Elevate Your Brand with Stunning Design
            </h1>
            <p className="text-lg text-secondary mb-8 leading-relaxed">
              We create memorable visual identities that capture your brand's essence. From logos to complete branding packages, we deliver fast, affordable, and high-quality design solutions tailored to your needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-white"
                onClick={() =>
                  document
                    .getElementById("contact")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
              >
                Start Your Project
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary text-primary hover:bg-primary/5"
              >
                View Portfolio
              </Button>
            </div>
            <div className="mt-12 grid grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold text-accent mb-2">50+</div>
                <p className="text-sm text-secondary">Happy Clients</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-accent mb-2">100+</div>
                <p className="text-sm text-secondary">Projects Completed</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-accent mb-2">5+</div>
                <p className="text-sm text-secondary">Years Experience</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 md:py-32 bg-white/50">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-primary mb-4">Our Services</h2>
            <p className="text-lg text-secondary">
              We offer comprehensive graphic design solutions tailored to your business needs
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {services.map((service, idx) => {
              const Icon = service.icon;
              return (
                <Card
                  key={idx}
                  className="p-8 border-border hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group"
                >
                  <div className="w-14 h-14 bg-accent/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-accent/20 transition-colors">
                    <Icon className="w-7 h-7 text-accent" />
                  </div>
                  <h3 className="text-primary mb-3">{service.title}</h3>
                  <p className="text-secondary leading-relaxed">
                    {service.description}
                  </p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 md:py-32">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-primary mb-4">Featured Work</h2>
            <p className="text-lg text-secondary">
              Explore our recent projects and see the quality of our designs
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {portfolio.map((item, idx) => (
              <div
                key={idx}
                className="group overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300"
              >
                <div className="relative h-64 overflow-hidden bg-muted">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-center justify-center">
                    <div className="text-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <h3 className="text-white font-semibold">{item.title}</h3>
                      <p className="text-white/80 text-sm">{item.category}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-20 md:py-32 bg-white/50">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-primary mb-4">What Our Clients Say</h2>
            <p className="text-lg text-secondary">
              Trusted by businesses across Lusaka and beyond
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {testimonials.map((testimonial, idx) => (
              <Card key={idx} className="p-8 border-border">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-accent text-lg">
                      ★
                    </span>
                  ))}
                </div>
                <p className="text-secondary mb-6 leading-relaxed italic">
                  "{testimonial.text}"
                </p>
                <div>
                  <p className="font-semibold text-primary">{testimonial.name}</p>
                  <p className="text-sm text-secondary">{testimonial.role}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section - Using Enhanced Component */}
      <ContactForm />

      {/* Footer */}
      <footer className="bg-primary text-white py-12 mt-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                  <span className="text-primary font-bold text-sm">JTM</span>
                </div>
                <span className="font-bold">J.T.M Graphics</span>
              </div>
              <p className="text-white/70 text-sm">
                Professional graphic design services in Lusaka, Zambia.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li>
                  <a href="#services" className="hover:text-white transition-colors">
                    Logo Design
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-white transition-colors">
                    Flyers & Posters
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-white transition-colors">
                    Brochures
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li>
                  <a href="#portfolio" className="hover:text-white transition-colors">
                    Portfolio
                  </a>
                </li>
                <li>
                  <a href="#contact" className="hover:text-white transition-colors">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="https://jtmdesigns.org" className="hover:text-white transition-colors">
                    Website
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li>+260 973689024</li>
                <li>clevermalako34@gmail.com</li>
                <li>Lusaka, Zambia</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 text-center text-sm text-white/60">
            <p>
              &copy; 2026 J.T.M Graphics. All rights reserved. | Crafted with
              care for creative excellence.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
