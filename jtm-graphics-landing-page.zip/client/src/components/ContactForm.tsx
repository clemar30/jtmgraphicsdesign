import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, Phone, MapPin, CheckCircle2, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

/**
 * Enhanced Contact Form Component
 * Features:
 * - Real-time field validation with visual feedback
 * - Email format validation
 * - Phone number format validation
 * - Success animation with confetti effect
 * - Accessible error messages
 * - Smooth transitions and micro-interactions
 */

interface FormData {
  name: string;
  email: string;
  phone: string;
  message: string;
}

interface ValidationErrors {
  name?: string;
  email?: string;
  phone?: string;
  message?: string;
}

export default function ContactForm() {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [errors, setErrors] = useState<ValidationErrors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  // Validation functions
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePhone = (phone: string): boolean => {
    if (!phone) return true; // Phone is optional
    const phoneRegex = /^[\d\s\-\+\(\)]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, "").length >= 7;
  };

  const validateField = (name: string, value: string): string | undefined => {
    switch (name) {
      case "name":
        if (!value.trim()) return "Name is required";
        if (value.trim().length < 2) return "Name must be at least 2 characters";
        return undefined;

      case "email":
        if (!value.trim()) return "Email is required";
        if (!validateEmail(value)) return "Please enter a valid email address";
        return undefined;

      case "phone":
        if (value && !validatePhone(value))
          return "Please enter a valid phone number";
        return undefined;

      case "message":
        if (!value.trim()) return "Message is required";
        if (value.trim().length < 10)
          return "Message must be at least 10 characters";
        return undefined;

      default:
        return undefined;
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // Real-time validation
    if (touched[name]) {
      const error = validateField(name, value);
      setErrors((prev) => ({
        ...prev,
        [name]: error,
      }));
    }
  };

  const handleBlur = (
    e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));

    // Validate on blur
    const error = validateField(name, value);
    setErrors((prev) => ({
      ...prev,
      [name]: error,
    }));
  };

  const validateForm = (): boolean => {
    const newErrors: ValidationErrors = {};

    Object.entries(formData).forEach(([key, value]) => {
      const error = validateField(key, value);
      if (error) {
        newErrors[key as keyof FormData] = error;
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Mark all fields as touched
    setTouched({
      name: true,
      email: true,
      phone: true,
      message: true,
    });

    if (!validateForm()) {
      toast.error("Please fix the errors above");
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Show success animation
    setShowSuccess(true);
    toast.success("Message sent successfully! We'll get back to you soon.");

    // Reset form after animation
    setTimeout(() => {
      setFormData({ name: "", email: "", phone: "", message: "" });
      setErrors({});
      setTouched({});
      setShowSuccess(false);
      setIsSubmitting(false);
    }, 2000);
  };

  const getFieldStatus = (
    fieldName: keyof FormData
  ): "valid" | "invalid" | "neutral" => {
    if (!touched[fieldName]) return "neutral";
    if (errors[fieldName]) return "invalid";
    if (formData[fieldName]) return "valid";
    return "neutral";
  };

  return (
    <section id="contact" className="py-20 md:py-32">
      <div className="container">
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <h2 className="text-primary mb-8">Get In Touch</h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <p className="font-semibold text-primary">Location</p>
                    <p className="text-secondary">Lusaka, Zambia</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <p className="font-semibold text-primary">Phone</p>
                    <p className="text-secondary">+260 973689024</p>
                    <p className="text-secondary text-sm">WhatsApp available</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <p className="font-semibold text-primary">Email</p>
                    <p className="text-secondary">clevermalako34@gmail.com</p>
                  </div>
                </div>
              </div>
              <div className="mt-8 p-6 bg-accent/5 rounded-lg border border-accent/20">
                <p className="text-sm text-secondary">
                  <span className="font-semibold text-primary">
                    Why Choose Us?
                  </span>
                  <br />
                  Fast turnaround • Affordable pricing • High-quality designs •
                  Professional service
                </p>
              </div>
            </div>

            {/* Enhanced Contact Form */}
            <div>
              <Card className="p-8 border-border relative overflow-hidden">
                {/* Success Animation Overlay */}
                {showSuccess && (
                  <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-accent/5 flex items-center justify-center z-50 animate-in fade-in duration-300">
                    <div className="text-center animate-in zoom-in-50 duration-500">
                      <div className="mb-4 flex justify-center">
                        <div className="relative w-20 h-20">
                          <CheckCircle2 className="w-20 h-20 text-accent animate-bounce" />
                          <div className="absolute inset-0 bg-accent/20 rounded-full animate-ping" />
                        </div>
                      </div>
                      <h3 className="text-xl font-bold text-primary mb-2">
                        Message Sent!
                      </h3>
                      <p className="text-secondary text-sm">
                        Thank you for reaching out. We'll be in touch soon.
                      </p>
                    </div>
                  </div>
                )}

                <h3 className="text-primary mb-6">Send us a Message</h3>
                <form onSubmit={handleSubmit} className="space-y-5">
                  {/* Name Field */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-primary">
                        Name <span className="text-accent">*</span>
                      </label>
                      {getFieldStatus("name") === "valid" && (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      )}
                    </div>
                    <Input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="Your name"
                      className={`border-border focus:border-accent focus:ring-accent transition-all ${
                        getFieldStatus("name") === "invalid"
                          ? "border-red-500 focus:border-red-500"
                          : getFieldStatus("name") === "valid"
                            ? "border-green-500 focus:border-green-500"
                            : ""
                      }`}
                      disabled={showSuccess}
                    />
                    {errors.name && touched.name && (
                      <div className="flex items-center gap-2 mt-2 text-red-500 text-sm animate-in fade-in slide-in-from-top-1 duration-200">
                        <AlertCircle className="w-4 h-4" />
                        {errors.name}
                      </div>
                    )}
                  </div>

                  {/* Email Field */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-primary">
                        Email <span className="text-accent">*</span>
                      </label>
                      {getFieldStatus("email") === "valid" && (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      )}
                    </div>
                    <Input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="your@email.com"
                      className={`border-border focus:border-accent focus:ring-accent transition-all ${
                        getFieldStatus("email") === "invalid"
                          ? "border-red-500 focus:border-red-500"
                          : getFieldStatus("email") === "valid"
                            ? "border-green-500 focus:border-green-500"
                            : ""
                      }`}
                      disabled={showSuccess}
                    />
                    {errors.email && touched.email && (
                      <div className="flex items-center gap-2 mt-2 text-red-500 text-sm animate-in fade-in slide-in-from-top-1 duration-200">
                        <AlertCircle className="w-4 h-4" />
                        {errors.email}
                      </div>
                    )}
                  </div>

                  {/* Phone Field */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-primary">
                        Phone
                      </label>
                      {getFieldStatus("phone") === "valid" && (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      )}
                    </div>
                    <Input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="+260 ..."
                      className={`border-border focus:border-accent focus:ring-accent transition-all ${
                        getFieldStatus("phone") === "invalid"
                          ? "border-red-500 focus:border-red-500"
                          : getFieldStatus("phone") === "valid"
                            ? "border-green-500 focus:border-green-500"
                            : ""
                      }`}
                      disabled={showSuccess}
                    />
                    {errors.phone && touched.phone && (
                      <div className="flex items-center gap-2 mt-2 text-red-500 text-sm animate-in fade-in slide-in-from-top-1 duration-200">
                        <AlertCircle className="w-4 h-4" />
                        {errors.phone}
                      </div>
                    )}
                  </div>

                  {/* Message Field */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-primary">
                        Message <span className="text-accent">*</span>
                      </label>
                      {getFieldStatus("message") === "valid" && (
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      )}
                    </div>
                    <Textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="Tell us about your project..."
                      rows={5}
                      className={`border-border focus:border-accent focus:ring-accent resize-none transition-all ${
                        getFieldStatus("message") === "invalid"
                          ? "border-red-500 focus:border-red-500"
                          : getFieldStatus("message") === "valid"
                            ? "border-green-500 focus:border-green-500"
                            : ""
                      }`}
                      disabled={showSuccess}
                    />
                    {errors.message && touched.message && (
                      <div className="flex items-center gap-2 mt-2 text-red-500 text-sm animate-in fade-in slide-in-from-top-1 duration-200">
                        <AlertCircle className="w-4 h-4" />
                        {errors.message}
                      </div>
                    )}
                  </div>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    disabled={isSubmitting || showSuccess}
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-accent-foreground border-t-transparent rounded-full animate-spin" />
                        Sending...
                      </div>
                    ) : (
                      "Send Message"
                    )}
                  </Button>
                </form>

                {/* Helper Text */}
                <p className="text-xs text-secondary mt-4 text-center">
                  We'll respond to your inquiry within 24 hours.
                </p>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
